// Dark/Light Mode Toggle
const themeBtn = document.querySelector('.theme-btn');
const body = document.body;

// Check for saved theme preference or default to dark mode
const currentTheme = localStorage.getItem('theme') || 'dark';
if (currentTheme === 'light') {
    body.classList.add('light-mode');
    updateThemeButton();
}

function updateThemeButton() {
    if (body.classList.contains('light-mode')) {
        themeBtn.textContent = '☀️';
    } else {
        themeBtn.textContent = '🌙';
    }
}

if (themeBtn) {
    themeBtn.addEventListener('click', () => {
        body.classList.toggle('light-mode');
        const theme = body.classList.contains('light-mode') ? 'light' : 'dark';
        localStorage.setItem('theme', theme);
        updateThemeButton();
    });
}

// Scroll to top button functionality
const scrollTopBtn = document.querySelector('.scroll-to-top');

window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        if (scrollTopBtn) scrollTopBtn.style.display = 'block';
    } else {
        if (scrollTopBtn) scrollTopBtn.style.display = 'none';
    }
});

// Newsletter form submission
const newsletterForm = document.querySelector('.newsletter-form');
if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const email = newsletterForm.querySelector('input[type="email"]').value;
        if (email) {
            alert('Thank you for subscribing! Check your email for confirmation.');
            newsletterForm.reset();
        }
    });
}

// Mobile menu toggle
const menuBtn = document.querySelector('.menu-btn');
if (menuBtn) {
    menuBtn.addEventListener('click', () => {
        console.log('Menu clicked');
    });
}

// Smooth scroll for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#') {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({ behavior: 'smooth' });
            }
        }
    });
});

// Add scroll-to-top button dynamically
const scrollBtn = document.createElement('button');
scrollBtn.className = 'scroll-to-top';
scrollBtn.innerHTML = '⬆';
scrollBtn.style.cssText = `
    position: fixed;
    bottom: 20px;
    right: 20px;
    background-color: #ff4444;
    color: white;
    border: none;
    padding: 12px 16px;
    border-radius: 50%;
    cursor: pointer;
    display: none;
    z-index: 99;
    font-size: 18px;
    width: 50px;
    height: 50px;
    transition: all 0.3s ease;
`;

scrollBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

scrollBtn.addEventListener('mouseover', () => {
    scrollBtn.style.backgroundColor = '#ff5555';
});

scrollBtn.addEventListener('mouseout', () => {
    scrollBtn.style.backgroundColor = '#ff4444';
});

document.body.appendChild(scrollBtn);

// Update scroll button visibility
window.addEventListener('scroll', () => {
    if (window.pageYOffset > 300) {
        scrollBtn.style.display = 'flex';
        scrollBtn.style.alignItems = 'center';
        scrollBtn.style.justifyContent = 'center';
    } else {
        scrollBtn.style.display = 'none';
    }
});
